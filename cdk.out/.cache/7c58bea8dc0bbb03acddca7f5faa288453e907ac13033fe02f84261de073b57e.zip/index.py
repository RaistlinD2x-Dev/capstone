def handler(event, context):

    x = 'hello'
    print(x)

    return x